# HW3 - Book Advisor

## How to run:
* python3 queryProcessor.py <file>.txt : to retrieve books and create a corpus
* python3 queryProcessor.py <url> : to find the recommendations of our system

### Mahir Efe KAYA
### 2016400195 